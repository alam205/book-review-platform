CREATE DATABASE IF NOT EXISTS book_review_db;

USE book_review_db;

CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  description TEXT,
  genre VARCHAR(255),
  ratings FLOAT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT,
  user_name VARCHAR(255) NOT NULL,
  rating INT NOT NULL,
  comment TEXT,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);
