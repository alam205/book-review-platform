const express = require('express');
const router = express.Router();
const { getBooks, getBookById, addBook } = require('../controllers/bookController');
const { protect } = require('../middlewares/authMiddleware');

router.route('/').get(getBooks).post(protect, addBook);
router.route('/:id').get(getBookById);

module.exports = router;
