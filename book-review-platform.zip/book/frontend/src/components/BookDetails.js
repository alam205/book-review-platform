import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchBookDetails } from '../api/bookApi';

const BookDetails = () => {
    const { id } = useParams();
    const [book, setBook] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadBookDetails = async () => {
            const data = await fetchBookDetails(id);
            setBook(data);
            setLoading(false);
        };
        loadBookDetails();
    }, [id]);

    if (loading) return <p>Loading...</p>;

    return (
        <div>
            <h1>{book.title}</h1>
            <p>{book.description}</p>
        </div>
    );
};

export default BookDetails;
