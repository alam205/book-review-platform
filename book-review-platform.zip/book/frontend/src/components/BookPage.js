import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const BookPage = () => {
  const { id } = useParams();
  const [book, setBook] = useState({});
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState({ user_name: '', rating: 0, comment: '' });

  useEffect(() => {
    axios.get(`http://localhost:5000/api/books/${id}`)
      .then((response) => setBook(response.data))
      .catch((error) => console.error(error));

    axios.get(`http://localhost:5000/api/reviews/${id}`)
      .then((response) => setReviews(response.data))
      .catch((error) => console.error(error));
  }, [id]);

  const handleReviewSubmit = () => {
    axios.post('http://localhost:5000/api/reviews', { ...newReview, book_id: id })
      .then((response) => setReviews([...reviews, response.data]))
      .catch((error) => console.error(error));
  };

  return (
    <div>
      <h1>{book.title}</h1>
      <p>{book.description}</p>

      <h2>Reviews</h2>
      <ul>
        {reviews.map((review) => (
          <li key={review.id}>{review.user_name}: {review.comment} ({review.rating}/5)</li>
        ))}
      </ul>

      <h3>Write a Review</h3>
      <input
        type="text"
        placeholder="Name"
        value={newReview.user_name}
        onChange={(e) => setNewReview({ ...newReview, user_name: e.target.value })}
      />
      <input
        type="number"
        placeholder="Rating"
        value={newReview.rating}
        onChange={(e) => setNewReview({ ...newReview, rating: e.target.value })}
      />
      <textarea
        placeholder="Comment"
        value={newReview.comment}
        onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
      />
      <button onClick={handleReviewSubmit}>Submit</button>
    </div>
  );
};

export default BookPage;
