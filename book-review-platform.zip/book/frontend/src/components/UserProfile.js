import React, { useContext, useEffect } from 'react';
import { UserContext } from '../context/UserContext';
import { fetchUserProfile } from '../api/userApi';

const UserProfile = () => {
    const { user, setUser } = useContext(UserContext);

    useEffect(() => {
        const loadUserProfile = async () => {
            const data = await fetchUserProfile('userId'); // replace with actual userId
            setUser(data);
        };
        loadUserProfile();
    }, [setUser]);

    if (!user) return <p>Loading...</p>;

    return (
        <div>
            <h2>{user.name}</h2>
            <p>{user.email}</p>
        </div>
    );
};

export default UserProfile;
