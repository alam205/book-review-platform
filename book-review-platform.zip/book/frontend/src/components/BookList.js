import React, { useContext } from 'react';
import { BookContext } from '../context/BookContext';
import { Link } from 'react-router-dom';

const BookList = () => {
    const { books, loading, error } = useContext(BookContext);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div>
            {books.map((book) => (
                <div key={book._id}>
                    <Link to={`/books/${book._id}`}>{book.title}</Link>
                </div>
            ))}
        </div>
    );
};

export default BookList;
