import axios from 'axios';

const BASE_URL = 'http://localhost:5000/api';

export const fetchUserProfile = async (id) => {
    const response = await axios.get(`${BASE_URL}/users/${id}`);
    return response.data;
};
