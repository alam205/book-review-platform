import React from 'react';
import BookList from '../components/BookList';

const BookListingPage = () => {
    return (
        <div>
            <h1>Book Listing</h1>
            <BookList />
        </div>
    );
};

export default BookListingPage;
