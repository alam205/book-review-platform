import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import BookListingPage from './pages/BookListingPage';
import BookDetails from './components/BookDetails';
import UserProfile from './components/UserProfile';
import Navbar from './components/Navbar';
import NotFoundPage from './pages/NotFoundPage';

const App = () => {
    return (
        <div>
            <Navbar />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/books" element={<BookListingPage />} />
                <Route path="/books/:id" element={<BookDetails />} />
                <Route path="/profile" element={<UserProfile />} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </div>
    );
};

export default App;
